# Member 3 — Seat Selection & Ticket Booking
## UE23CS352B | OOAD Mini Project | Movie Ticket Booking System

---

## Your Ownership

### Files You Implemented & Must Explain

| Layer | File | Your Responsibility |
|-------|------|---------------------|
| Controller | `BookingController.java` | Seat selection, confirm booking, confirmation page, history, cancel |
| Service | `BookingService.java` | bookTickets(), cancelBooking(), observer notification |
| Model | `Booking.java` | Booking entity, createTicket() method, status/payment enums |
| Model | `Seat.java` | Seat entity, SeatStatus, SeatType, @Column reserved word fix |
| Model | `Ticket.java` | Ticket entity linked to Booking and Seat |
| Pattern | `BookingObserver.java` | Observer interface + Email + SMS + BookingEventPublisher |
| Repository | `BookingRepository.java` | findByUserId(), findByStatus() |
| Repository | `SeatRepository.java` | findByShowId(), findByShowIdAndStatus() |
| Repository | `TicketRepository.java` | findByBookingId() |
| Templates | `user/seat-selection.html` | Interactive seat map with JS price calculator |
| Templates | `user/booking-confirmation.html` | Confirmation ticket view |
| Templates | `user/booking-history.html` | User's booking list with cancel button |

---

## Your GRASP Principle: CREATOR

### Definition
The GRASP Creator principle states: assign class B the responsibility to create
instances of class A if B contains A, B aggregates A, B has the data needed
to initialize A, or B closely uses A.

### How it appears in your code

**Booking.java — Creator of Ticket objects:**
```java
@Entity
public class Booking {
    private User user;
    private Show show;
    private List<Ticket> tickets;  // Booking CONTAINS Tickets
    private double totalAmount;

    // GRASP Creator: Booking creates Ticket because it:
    // 1. Contains/aggregates Ticket objects (List<Ticket>)
    // 2. Has all data needed to initialize Ticket (show price, seat info)
    // 3. Closely uses Ticket throughout its lifecycle
    public Ticket createTicket(Seat seat) {
        return Ticket.builder()
                .booking(this)              // Booking knows itself
                .seat(seat)                 // Booking has the seat reference
                .seatNumber(seat.getSeatNumber())
                .price(this.show.getTicketPrice())  // Booking knows the show price
                .build();
    }
}
```

**Also in BookingService.java — using TicketFactory as the designated creator:**
```java
// BookingService delegates ticket creation to TicketFactory (also a Creator)
for (Seat seat : seats) {
    Ticket ticket = TicketFactory.createTicket(booking, seat);
    // TicketFactory has all data needed — it is the GRASP Creator for Ticket
}
```

**Key point to say in demo:** "When a user books seats, BookingService creates
a Booking object. The Booking object is the natural creator of Ticket objects
because it contains them (List<Ticket>), it aggregates them, and it has all the
data needed — the show price, the seat reference, the booking itself.
This is the GRASP Creator principle — responsibility for creating an object
belongs to the class that has the most information about it."

---

## Your Design Pattern: OBSERVER PATTERN

### Definition
The Observer pattern defines a one-to-many dependency so that when one object
(the subject/publisher) changes state, all its dependents (observers) are
notified automatically without tight coupling.

### How it appears in your code — BookingObserver.java

```
BookingObserver (interface)
    ├── EmailNotificationObserver → prints [EMAIL] confirmation
    └── SmsNotificationObserver   → prints [SMS] confirmation

BookingEventPublisher (Subject)
    └── List<BookingObserver> observers
        ├── subscribe(observer)
        ├── notifyConfirmed(booking) → calls all observers
        └── notifyCancelled(booking) → calls all observers
```

**BookingService.java — publishing the event:**
```java
private final List<BookingObserver> observers = new ArrayList<>();

public void registerObserver(BookingObserver observer) {
    observers.add(observer);  // register Email, SMS, etc.
}

// After booking is confirmed:
final Booking confirmed = booking;
observers.forEach(o -> o.onBookingConfirmed(confirmed));
// BookingService doesn't know if it's Email or SMS — it just notifies all
```

**Observer output visible in console during demo:**
```
[EMAIL] Sent booking confirmation to arjun@example.com for movie: Kalki 2898 AD | Booking ID: 1 | Amount: ₹500.0
[SMS] Sent confirmation SMS for Booking ID: 1
```

**Key point to say in demo:** "When a booking is confirmed, BookingService calls
observers.forEach(o -> o.onBookingConfirmed(booking)). It doesn't know whether
Email or SMS is registered — it just notifies all registered observers.
If we want to add WhatsApp notifications, we create WhatsAppObserver implements
BookingObserver and register it — zero changes to BookingService.
This is the Observer pattern — loose coupling between event publisher and handlers."

---

## Major Use Case: Seat Selection & Ticket Booking
## Minor Use Case: Booking Confirmation page

---

## Demo Script (5–7 minutes)

1. Login as `arjun@example.com / user123`
2. Go to a movie → click a show → seat selection page
3. Click VIP seats (gold border) — show price = 2x base price updating in real time
4. Click Premium seats (blue border) — show 1.5x pricing
5. Select 2-3 seats → select UPI payment → click Confirm Booking
6. Show booking confirmation page with ticket details and booking ID
7. **Show console output** — `[EMAIL]` and `[SMS]` observer notifications printed
8. Go to `/booking/history` — show the confirmed booking
9. Cancel the booking — show status changes to "Cancelled", seats freed
10. **Explain in code:** Open `Booking.java` → show createTicket() → GRASP Creator
11. **Explain in code:** Open `BookingObserver.java` → show Observer pattern
12. Open `BookingService.java` → show observers.forEach → publisher notifies all

---

## Credentials for Demo
- User: `arjun@example.com` / `user123`

## Run Command
```bash
cd member3
mvn spring-boot:run
```
Open: http://localhost:8080
