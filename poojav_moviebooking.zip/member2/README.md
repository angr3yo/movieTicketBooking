# Member 2 — Movie Browsing & Show Management
## UE23CS352B | OOAD Mini Project | Movie Ticket Booking System

---

## Your Ownership

### Files You Implemented & Must Explain

| Layer | File | Your Responsibility |
|-------|------|---------------------|
| Controller | `MovieController.java` | Browse movies, search, genre filter, movie detail |
| Controller | `AdminController.java` (movies + shows sections) | Add/Edit/Delete movies, Add/Delete shows |
| Service | `MovieService.java` | addMovie, searchMovies, getNowShowing, getByGenre |
| Service | `ShowService.java` | createShow, generateSeatsForShow, getAllShows |
| Model | `Movie.java` | Movie entity, MovieStatus enum |
| Model | `Show.java` | Show entity, links Movie ↔ Theatre |
| Model | `Theatre.java` | Theatre entity |
| Pattern | `TicketFactory.java` | Factory method creating typed tickets |
| Repository | `MovieRepository.java` | searchMovies() custom @Query |
| Repository | `ShowRepository.java` | findAvailableShowsByMovie() |
| Repository | `TheatreRepository.java` | findByLocation() |
| Templates | `user/movies.html` | Movie listing page |
| Templates | `user/movie-detail.html` | Movie detail + show times |
| Templates | `admin/movies.html` | Admin movie list |
| Templates | `admin/movie-form.html` | Add/Edit movie form |
| Templates | `admin/shows.html` | Admin show management |

---

## Your GRASP Principle: INFORMATION EXPERT

### Definition
The GRASP Information Expert principle states: assign responsibility to the class
that has the information needed to fulfill it. The class that knows the data
is the expert — it should be the one to answer questions about it.

### How it appears in your code

**Movie.java — Information Expert for its own status:**
```java
@Entity
public class Movie {
    private MovieStatus status;  // Movie KNOWS its own status
    private double rating;       // Movie KNOWS its own rating
    private String genre;        // Movie KNOWS its own genre

    // MovieService asks Movie questions — Movie is the expert
    public enum MovieStatus { NOW_SHOWING, COMING_SOON, ENDED }
}
```

**Show.java — Information Expert for seat availability:**
```java
@Entity
public class Show {
    private int availableSeats;   // Show KNOWS how many seats are left
    private double ticketPrice;   // Show KNOWS the price for that screening

    // BookingService asks show.getAvailableSeats() — Show is the expert
}
```

**MovieRepository.java — Information Expert query:**
```java
@Query("SELECT m FROM Movie m WHERE LOWER(m.title) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
       "OR LOWER(m.genre) LIKE LOWER(CONCAT('%', :keyword, '%'))")
List<Movie> searchMovies(String keyword);
// Movie repository is the expert on how to find movies — this logic lives here
```

**Key point to say in demo:** "When a user searches for a movie, MovieController calls
movieService.searchMovies(keyword). The actual query logic lives in MovieRepository
because the repository is the Information Expert — it has the data access knowledge.
Show.availableSeats lives in Show because Show is the expert on its own capacity.
We didn't put that logic in BookingService. This is the GRASP Information Expert principle."

---

## Your Design Pattern: FACTORY PATTERN

### Definition
The Factory pattern provides an interface for creating objects without specifying
the exact class to instantiate. The factory decides which concrete type to create
based on input parameters.

### How it appears in your code — TicketFactory.java

```java
public class TicketFactory {

    // Factory Method — caller doesn't know how ticket is priced
    public static Ticket createTicket(Booking booking, Seat seat) {
        double basePrice = booking.getShow().getTicketPrice();

        // Factory decides price multiplier based on seat TYPE
        double finalPrice = switch (seat.getType()) {
            case PREMIUM -> basePrice * 1.5;   // Premium = 1.5x
            case VIP     -> basePrice * 2.0;   // VIP = 2x
            default      -> basePrice;          // Regular = base price
        };

        return Ticket.builder()    // Creates and returns the Ticket object
                .booking(booking)
                .seat(seat)
                .seatNumber(seat.getSeatNumber())
                .price(finalPrice)
                .build();
    }
}
```

**Used in BookingService:**
```java
// BookingService uses the factory — doesn't construct Ticket directly
Ticket ticket = TicketFactory.createTicket(booking, seat);
// BookingService doesn't know how pricing works — Factory encapsulates it
```

**Key point to say in demo:** "When a booking is made, BookingService calls
TicketFactory.createTicket(). The factory checks whether the seat is VIP, Premium,
or Regular and applies the correct price multiplier. BookingService doesn't know
how tickets are priced — that knowledge is encapsulated in the Factory.
If we add a new seat type (e.g. LUXURY at 3x), we only change TicketFactory.
This is the Factory pattern — object creation logic is centralized and hidden."

---

## Major Use Case: Movie Catalog & Show Management
## Minor Use Case: Search by title/genre, filter by genre chips

---

## Demo Script (5–7 minutes)

1. Open `http://localhost:8080/movies` — show the full movie grid (12+ movies)
2. Click a genre chip (e.g. "Action") — show filtered results
3. Type in search bar (e.g. "Interstellar") — show search results
4. Click on a movie → movie detail page with show timings
5. Show different show prices at different theatres
6. Login as admin → `/admin/movies` → Add a new movie (fill the form)
7. Go to `/admin/shows` → Add a new show for that movie
8. **Explain in code:** Open `MovieController.java` → show Information Expert
9. **Explain in code:** Open `TicketFactory.java` → show Factory pattern + price switch
10. Open `ShowService.generateSeatsForShow()` → show how 120 seats auto-generated

---

## Credentials for Demo
- Admin: `admin@movies.com` / `admin123`

## Run Command
```bash
cd member2
mvn spring-boot:run
```
Open: http://localhost:8080
