# Member 1 — User Authentication & Registration
## UE23CS352B | OOAD Mini Project | Movie Ticket Booking System

---

## Your Ownership

### Files You Implemented & Must Explain

| Layer | File | Your Responsibility |
|-------|------|---------------------|
| Controller | `AuthController.java` | Login page, Register page, POST /register |
| Service | `UserService.java` | registerUser(), findByEmail(), password encoding |
| Model | `User.java` | User entity, Role enum (USER/ADMIN) |
| Config | `SecurityConfig.java` | Spring Security rules, BCrypt, UserDetailsService |
| Pattern | `PaymentStrategy.java` | Interface + UPI/Card/NetBanking/Wallet strategies |
| Repository | `UserRepository.java` | findByEmail(), existsByEmail() |

---

## Your GRASP Principle: CONTROLLER

### Definition
The GRASP Controller principle states that a non-UI class should be responsible for
receiving and coordinating system events. It is the first object beyond the UI layer
that handles a system operation.

### How it appears in your code — AuthController.java

```java
@Controller
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;  // delegates to service, never does business logic itself

    @GetMapping("/login")
    public String loginPage(...) { ... }   // receives HTTP event → routes to view

    @PostMapping("/register")
    public String registerUser(...) {
        // AuthController is the CONTROLLER — it:
        // 1. Receives the system event (POST /register)
        // 2. Validates input (passwords match)
        // 3. Delegates to UserService (never does registration logic itself)
        // 4. Returns the next view
        userService.registerUser(name, email, password);
    }
}
```

**Key point to say in demo:** "AuthController does not contain any business logic.
It only receives the HTTP request, validates form inputs, and delegates to UserService.
This is the GRASP Controller principle — a dedicated class handles system events
and coordinates the response, keeping the view and business logic separate."

---

## Your Design Pattern: STRATEGY PATTERN

### Definition
The Strategy pattern defines a family of algorithms, encapsulates each one,
and makes them interchangeable. The client selects which algorithm to use at runtime.

### How it appears in your code — PaymentStrategy.java

```
PaymentStrategy (interface)
    ├── UpiPaymentStrategy        → pay() sends UPI request
    ├── CardPaymentStrategy       → pay() processes card
    ├── NetBankingPaymentStrategy → pay() redirects to bank
    └── WalletPaymentStrategy     → pay() deducts from wallet
```

```java
// Interface (the Strategy)
public interface PaymentStrategy {
    boolean pay(double amount);
    String getPaymentMethodName();
}

// Concrete Strategy — can be swapped at runtime
class UpiPaymentStrategy implements PaymentStrategy {
    public boolean pay(double amount) {
        System.out.println("Processing UPI payment of ₹" + amount);
        return true;
    }
}

// Context picks strategy based on user's choice
PaymentStrategy strategy = PaymentStrategyFactory.getStrategy("UPI", "user@upi", "");
strategy.pay(500.0);  // executes UPI logic without the caller knowing how
```

**Key point to say in demo:** "The user selects UPI, Card, Net Banking or Wallet on the
seat selection page. The BookingService receives the string 'UPI' and the
PaymentStrategyFactory creates a UpiPaymentStrategy. The service calls pay() without
knowing which payment method it is — it just uses the interface. This is the
Strategy pattern — the algorithm (payment method) is selected and swapped at runtime."

---

## Major Use Case: User Registration & Login
## Minor Use Case: Login error handling, logout flow

---

## Demo Script (5–7 minutes)

1. Open `http://localhost:8080/register`
2. Register a new user — show validation (passwords don't match → error message)
3. Try registering with same email → show duplicate email error
4. Login with new user credentials
5. Show failed login → "Invalid email or password"
6. Login as admin (`admin@movies.com / admin123`) → show role-based redirect
7. Logout → redirects to login with "You have been logged out"
8. **Explain in code:** Open `AuthController.java` → show GRASP Controller
9. **Explain in code:** Open `PaymentStrategy.java` → show Strategy interface + 4 impls
10. Show `SecurityConfig.java` → explain BCrypt password encoding

---

## Credentials for Demo
- Admin: `admin@movies.com` / `admin123`
- User: `arjun@example.com` / `user123`

## Run Command
```bash
cd member1
mvn spring-boot:run
```
Open: http://localhost:8080
