# Member 4 — Admin Dashboard & Booking Management
## UE23CS352B | OOAD Mini Project | Movie Ticket Booking System

---

## Your Ownership

### Files You Implemented & Must Explain

| Layer | File | Your Responsibility |
|-------|------|---------------------|
| Controller | `AdminController.java` (dashboard + theatres + bookings + users) | Dashboard stats, theatre CRUD, view all bookings, manage users |
| Config | `DataSeeder.java` | Seeds all sample data on startup (movies, theatres, shows, users) |
| Repository | `BookingRepository.java` | findByUserId(), findByStatus() |
| Repository | `TheatreRepository.java` | findByLocation() |
| Pattern | `PaymentStrategy.java` — PaymentStrategyFactory class | Bridges string→PaymentStrategy object (Adapter) |
| Templates | `admin/dashboard.html` | Stats dashboard with 4 stat cards |
| Templates | `admin/theatres.html` | Theatre management (add/delete) |
| Templates | `admin/bookings.html` | All bookings table |
| Templates | `admin/users.html` | User management with delete |

---

## Your GRASP Principle: LOW COUPLING

### Definition
The GRASP Low Coupling principle states: design classes so that they have fewer
dependencies on other classes. Low coupling means changes in one class have
minimal impact on others. It is achieved by depending on interfaces/abstractions
rather than concrete implementations.

### How it appears in your code

**AdminController.java — depends on service interfaces, not concrete classes:**
```java
@Controller
@RequiredArgsConstructor
public class AdminController {

    // LOW COUPLING: AdminController depends on SERVICE ABSTRACTIONS
    // not on repositories, JPA, or database directly
    private final MovieService movieService;      // interface/service abstraction
    private final ShowService showService;        // interface/service abstraction
    private final BookingService bookingService;  // interface/service abstraction
    private final UserService userService;        // interface/service abstraction
    private final TheatreRepository theatreRepository;  // minimal direct repo use

    @GetMapping
    public String dashboard(Model model) {
        // AdminController calls service methods — no SQL, no JPA, no Hibernate
        model.addAttribute("totalMovies",   movieService.getAllMovies().size());
        model.addAttribute("totalBookings", bookingService.getAllBookings().size());
        // If MovieService implementation changes, AdminController is UNAFFECTED
    }
}
```

**The result of Low Coupling:**
- If we swap `MovieService` implementation (e.g. add caching), `AdminController` requires ZERO changes
- `AdminController` has no `import org.springframework.data.jpa.*` — it never touches JPA directly
- Each service can be tested/modified independently

**Key point to say in demo:** "AdminController depends on MovieService, ShowService,
BookingService, and UserService — all service-layer abstractions. It never imports JPA,
never touches repositories directly (except TheatreRepository for simplicity).
If we change how movies are stored, AdminController doesn't change.
This is the GRASP Low Coupling principle — minimize dependencies between classes
so changes in one don't cascade into others."

---

## Your Design Pattern: ADAPTER PATTERN

### Definition
The Adapter pattern converts the interface of a class into another interface that
clients expect. It lets incompatible interfaces work together by wrapping one
interface and translating calls to another.

### How it appears in your code — PaymentStrategyFactory in PaymentStrategy.java

```java
// The web form sends a plain String: "UPI", "CARD", "NET_BANKING", "WALLET"
// BookingService expects a PaymentStrategy object
// These two interfaces are INCOMPATIBLE — Adapter bridges them

class PaymentStrategyFactory {
    // ADAPTER: converts String input → PaymentStrategy object
    public static PaymentStrategy getStrategy(String method, String detail1, String detail2) {
        return switch (method.toUpperCase()) {
            case "UPI"         -> new UpiPaymentStrategy(detail1);
            case "CARD"        -> new CardPaymentStrategy(detail1, detail2);
            case "NET_BANKING" -> new NetBankingPaymentStrategy(detail1);
            case "WALLET"      -> new WalletPaymentStrategy(detail1);
            default -> throw new IllegalArgumentException("Unknown payment method: " + method);
        };
    }
}
```

```
Web Form (sends "UPI" string)
        ↓
PaymentStrategyFactory.getStrategy("UPI", ...)   ← ADAPTER
        ↓
UpiPaymentStrategy (PaymentStrategy interface)
        ↓
BookingService.pay(amount)
```

**Key point to say in demo:** "The seat selection page sends the payment method as
a plain string — 'UPI', 'CARD', etc. But BookingService needs a PaymentStrategy
object to call pay(). These two interfaces are incompatible.
PaymentStrategyFactory acts as an Adapter — it receives the string from the web layer
and returns the correct PaymentStrategy implementation.
This is the Adapter pattern — translating one interface to another."

---

## Major Use Case: Admin Dashboard & CRUD Operations
## Minor Use Case: Booking History view (user side), Cancel booking

---

## Demo Script (5–7 minutes)

1. Login as admin: `admin@movies.com / admin123`
2. Show dashboard at `/admin` — 4 stat cards (Movies, Shows, Bookings, Users)
3. Click each stat card — navigates to that section
4. Go to `/admin/theatres` → Add a new theatre (name, location, seats)
5. Show the new theatre appears in the table
6. Go to `/admin/bookings` → Show all bookings table with seats and amount
7. Go to `/admin/users` → Show user list, delete a user
8. Go to `/admin/shows` → Show add form + existing shows table
9. Switch to user account → `/booking/history` → view confirmed bookings
10. **Explain in code:** Open `AdminController.java` → show Low Coupling (service deps)
11. **Explain in code:** Open `PaymentStrategy.java` → scroll to `PaymentStrategyFactory`
    → show Adapter: String → PaymentStrategy object conversion
12. Open `DataSeeder.java` → explain how sample data is seeded on startup

---

## Credentials for Demo
- Admin: `admin@movies.com` / `admin123`
- User: `arjun@example.com` / `user123`

## Run Command
```bash
cd member4
mvn spring-boot:run
```
Open: http://localhost:8080/admin
